
(function ($) {
	"use strict";
   
	   /*----------------------------
		jQuery MeanMenu
	   ------------------------------ */
	   jQuery('nav#dropdown').meanmenu();	
	   /*----------------------------
	   
   /*--------------------------
	scrollUp
   ---------------------------- */	
	   $.scrollUp({
		   scrollText: '<i class="fa fa-angle-up"></i>',
		   easingType: 'linear',
		   scrollSpeed: 900,
		   animation: 'fade'
	   }); 	   

	   
	
   })(jQuery); 


   
   