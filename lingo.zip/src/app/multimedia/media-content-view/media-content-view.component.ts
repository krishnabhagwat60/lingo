import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-media-content-view',
  templateUrl: './media-content-view.component.html',
  styleUrls: ['./media-content-view.component.css']
})
export class MediaContentViewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
