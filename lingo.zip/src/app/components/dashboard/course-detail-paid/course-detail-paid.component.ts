import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-detail-paid',
  templateUrl: './course-detail-paid.component.html',
  styleUrls: ['./course-detail-paid.component.css']
})
export class CourseDetailPaidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
}
