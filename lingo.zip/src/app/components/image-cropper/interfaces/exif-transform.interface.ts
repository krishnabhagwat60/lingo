export interface ExifTransform {
    rotate: number;
    flip: boolean;
}
